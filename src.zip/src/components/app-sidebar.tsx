"use client"

import React, { useMemo } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Calendar,
  ChartNoAxesCombined,
  Component,
  Factory,
  FileChartColumn,
  HelpCircleIcon,
  LayoutDashboardIcon,
  LayoutList,
  Package,
  SearchIcon,
  SettingsIcon,
  UserRound,
  UsersIcon,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { NavMain } from "./nav-main"

// Mock para NavSecondary caso não exista
let NavSecondary: any
try {
  NavSecondary = require("./nav-secondary").NavSecondary
} catch {
  NavSecondary = () => null
}
// Mock para NavUser caso não exista
let NavUser: any
try {
  NavUser = require("./nav-user").NavUser
} catch {
  NavUser = () => null
}

export const AppSidebar = React.memo(function AppSidebar(props: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname()
  const data = useMemo(() => ({
    user: {
      name: "shadcn",
      email: "m@example.com",
      avatar: "/avatars/shadcn.jpg",
    },
    navMain: [
      { title: "Dashboard", url: "/dashboard", icon: LayoutDashboardIcon },
      { title: "Clientes", url: "/customers", icon: UserRound },
      { title: "Consultas", url: "/queries", icon: Calendar },
      { title: "Pedidos", url: "/orders", icon: LayoutList },
      { title: "Estoque", url: "/inventory", icon: Package },
      { title: "Financeiro", url: "/finance", icon: ChartNoAxesCombined },
      { title: "Colaboradores", url: "/collaborators", icon: UsersIcon },
      { title: "Fornecedores", url: "/suppliers", icon: Factory },
      { title: "Relatórios", url: "/reports", icon: FileChartColumn },
      { title: "Integrações", url: "/integrations", icon: Component },
    ],
    navSecondary: [
      { title: "Configurações", url: "/settings", icon: SettingsIcon },
      { title: "Ajuda", url: "/help", icon: HelpCircleIcon },
      { title: "Pesquisar", url: "/search", icon: SearchIcon },
    ],
  }), [])

  return (
    <Sidebar collapsible="offcanvas" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              asChild
              className="data-[slot=sidebar-menu-button]:!p-1.5"
            >
              <Link href="/">
                <span className="text-xl font-semibold">Visao +</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={data.navMain} />
        <NavSecondary items={data.navSecondary} className="mt-auto" />
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={data.user} />
      </SidebarFooter>
    </Sidebar>
  )
})