// app/admin/page.tsx
import { createServerComponentClient } from '@supabase/auth-helpers-nextjs' // Updated import
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'

export default async function AdminPage() {
  const supabase = createServerComponentClient({ cookies }) // Updated function

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect('/login')
  }

  const { data: userData } = await supabase
    .from('users')
    .select('role')
    .eq('id', session.user.id)
    .single()

  if (userData?.role !== 'admin') {
    redirect('/')
  }

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      {/* Add admin-specific content */}
    </div>
  )
}